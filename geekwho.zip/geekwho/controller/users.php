<?php

require_once dirname(__DIR__) . '/view/users.php';

class Users{

    public function generateNavigation($titleSite, $mainAddress){
        switch ($titleSite){

            case $titleSite == "";
                return $output = "";

        }
    }

}

$users = new Users();