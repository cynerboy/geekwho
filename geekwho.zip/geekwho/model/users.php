<?php

require_once(dirname(__DIR__). "/controller/databaseApi.php");

class ModelUsers{



}

$modelUsers = new ModelUsers();