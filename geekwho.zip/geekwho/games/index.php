<?php
$titleSite = "GeekWho Games";
include ('../layout/header.php');
?>
    <!-- this is a start -->
    <div class="row">

        <div class="col-3">

            <ul class="list-group">
                <li class="list-group-item">
                    <button type="button" class="btn btn-primary">ثبت بازی جدید</button>
                </li>
                <li class="list-group-item">
                    <div style="font-family:btitr; font-size:25px;">
                        سکو
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                        <label class="form-check-label" for="flexSwitchCheckDefault">کامپیوتر</label>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked">
                        <label class="form-check-label" for="flexSwitchCheckChecked">موبایل</label>
                    </div>
                </li>
                <li class="list-group-item">
                    <div style="font-family:btitr; font-size:25px;">
                        سبک بازی
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckDefault">
                        <label class="form-check-label" for="flexSwitchCheckDefault">داستان محور</label>
                    </div>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked">
                        <label class="form-check-label" for="flexSwitchCheckChecked">آنلاین</label>
                    </div>
                </li>
                <li class="list-group-item">
                    <div style="font-family:btitr; font-size:25px;">
                        تاریخ انتشار بازی
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault1" checked>
                        <label class="form-check-label" for="flexRadioDefault1">
                            نزولی
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="flexRadioDefault" id="flexRadioDefault2">
                        <label class="form-check-label" for="flexRadioDefault2">
                            صعودی
                        </label>
                    </div>
                </li>
            </ul>

        </div>

        <div class="col-9">

            <div class="row">

                <div class="col text-center">
                    <div class="card h-60">
                        <img src="https://gamefa.com/wp-content/uploads/2021/04/Outriders-2-200x100.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">2016</small>
                        </div>
                    </div>
                </div>
                <div class="col text-center">
                    <div class="card h-60">
                        <img src="https://gamefa.com/wp-content/uploads/2021/04/Outriders-2-200x100.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">2016</small>
                        </div>
                    </div>
                </div>
                <div class="col text-center">
                    <div class="card h-60">
                        <img src="https://gamefa.com/wp-content/uploads/2021/04/Outriders-2-200x100.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">2016</small>
                        </div>
                    </div>
                </div>
                <div class="col text-center">
                    <div class="card h-60">
                        <img src="https://gamefa.com/wp-content/uploads/2021/04/Outriders-2-200x100.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">بازی خوب</h5>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">2016</small>
                        </div>
                    </div>
                </div>

            </div>

            <br>

            <div class="row">

                <div class="col text-center">
                    <div class="card h-60">
                        <img src="https://gamefa.com/wp-content/uploads/2021/04/Outriders-2-200x100.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">2016</small>
                        </div>
                    </div>
                </div>
                <div class="col text-center">
                    <div class="card h-60">
                        <img src="https://gamefa.com/wp-content/uploads/2021/04/Outriders-2-200x100.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">2016</small>
                        </div>
                    </div>
                </div>
                <div class="col text-center">
                    <div class="card h-60">
                        <img src="https://gamefa.com/wp-content/uploads/2021/04/Outriders-2-200x100.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">Card title</h5>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">2016</small>
                        </div>
                    </div>
                </div>
                <div class="col text-center">
                    <div class="card h-60">
                        <img src="https://gamefa.com/wp-content/uploads/2021/04/Outriders-2-200x100.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title">بازی خوب</h5>
                        </div>
                        <div class="card-footer">
                            <small class="text-muted">2016</small>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
    <!-- this is a end -->

<?php
include ('../layout/footer.php');
?>