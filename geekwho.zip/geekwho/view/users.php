<?php

class ViewUsers{

    public function makeNavigationBar($titleSite){
        if($titleSite == "GeekWho Review Games"){

        }else{
            return;
        }
    }

}

$viewUsers = new ViewUsers();