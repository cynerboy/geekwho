<?php require_once dirname(__DIR__) . '/config/initializeAddress.php' ?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="<?php echo SITE_ROOT . 'boot/css/bootstrap.min.css'; ?>">
    <link rel="stylesheet" href="<?php echo SITE_ROOT . 'boot/css/bootstrap.rtl.min.css'; ?>">
    <link rel="stylesheet" href="<?php echo SITE_ROOT . 'boot/css/custom.css'; ?>">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo SITE_ROOT . 'apple-touch-icon.png'; ?>">
    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo SITE_ROOT . 'favicon-32x32.png'; ?>">
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo SITE_ROOT . 'favicon-16x16.png'; ?>">
    <link rel="manifest" href="<?php echo SITE_ROOT . 'site.webmanifest'; ?>">
    <title><?php echo $titleSite; ?></title>
</head>
<body>
<!-- start container -->
<div class="container">
    <!-- start header website -->
    <div class="row">
        ​
        <div class="col text-center">

            <img src="<?php echo SITE_ROOT . 'pictures/logo.jpg'; ?>" class="rounded" alt="logo">

        </div>

    </div>
    <!-- end header website -->
    <!-- start navigation bar website -->
    <div class="row">

        <div class="col">

            <ul class="nav nav-pills nav-fill">
                <li class="nav-item">
                    <a class="nav-link" href="#">وارد سایت شوید</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if($titleSite == "GeekWho Review Games"){ echo "active"; } ?>" aria-current="page" href="<?php echo SITE_ROOT ?>">نقد های بازی</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if($titleSite == "GeekWho Games"){ echo "active"; } ?>"  href="<?php echo SITE_ROOT . 'games' ?>">بازی ها</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if($titleSite == "GeekWho Tops"){ echo "active"; } ?>" href="<?php echo SITE_ROOT . 'tops' ?>">نمرات بازی ها و منتقدان برتر</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if($titleSite == "GeekWho Artists"){ echo "active"; } ?>" href="<?php echo SITE_ROOT . 'artists' ?>">هنرمندان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if($titleSite == "GeekWho Assist"){ echo "active"; } ?>" href="<?php echo SITE_ROOT . 'assist' ?>">مشارکت هنرمندان</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php if($titleSite == "GeekWho About"){ echo "active"; } ?>" href="<?php echo SITE_ROOT . 'about' ?>">درباره سایت</a>
                </li>
            </ul>

        </div>

    </div>
    <!-- end navigation bar website -->

    <br>