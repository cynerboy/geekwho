<?php require_once dirname(__DIR__) . '/config/initializeAddress.php';
    require_once dirname(__DIR__) . '/controller/databaseApi.php';
?>
    </div>
    <!-- end container -->
    <!-- start Option 1: Bootstrap Bundle with Popper -->
    <script src="<?php echo SITE_ROOT . 'boot/js/bootstrap.bundle.min.js'; ?>" language="JavaScript" type="text/javascript"></script>
    <!-- end Option 1: Bootstrap Bundle with Popper -->
    </body>
    </html>
<?php $db->CloseConnection(); ?>