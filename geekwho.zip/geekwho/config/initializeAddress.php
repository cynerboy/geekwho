<?php
define('DS', DIRECTORY_SEPARATOR);
define ('ROOT_DIR', __DIR__);
define('SITE_ROOT', 'http://localhost/geekwho/');