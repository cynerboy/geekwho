<?php

define('DB_NAME','geekwho');
define('DB_SERVER','localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', '');